#include "NCSActivity.hh"

class TransActivity : public NCSActivity {
public:
    TransActivity();
    ~TransActivity();
};
