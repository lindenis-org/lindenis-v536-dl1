#define REGISTER_NCS() \
    MGNCS_INIT_CLASS(mWidgetHostPiece);

#define UNREGISTER_NCS()
