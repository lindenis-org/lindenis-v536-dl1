#ifndef __MDTV_CONFIG_H
#define __MDTV_CONFIG_H

#include "../mdtvconfig.h"

#endif
