#ifndef MDTV_WEATHER_H
#define MDTV_WEATHER_H

HWND InitWeatherWnd(void);
#endif/* MDTV_WEATHER_H */
