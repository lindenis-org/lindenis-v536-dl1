
#ifndef __NETWORK_H__
#define __NETWORK_H__ 

#define TRACE(msg...) fprintf(stderr, msg)
void register_networkobject(void);
void register_homepage(void);

#endif // __NETWORK_H__
