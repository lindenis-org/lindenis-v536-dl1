#ifndef _MDOLPHIN_SEARCH_H
#define _MDOLPHIN_SEARCH_H

#include <minigui/common.h>
#include <minigui/minigui.h>
#include <minigui/gdi.h>
#include <minigui/window.h>
#include <minigui/control.h>

void navigate_to_search(HWND hWnd);
#endif
