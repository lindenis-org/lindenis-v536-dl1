#ifndef MDTV_SETTING_HOMEPAGE_H
#define MDTV_SETTING_HOMEPAGE_H

void register_homepage(void);
char* get_setted_home_url();
#endif
