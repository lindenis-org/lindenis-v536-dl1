#ifndef _MDTV_WEBSITE_H
#define _MDTV_WEBSITE_H

#include <minigui/common.h>
#include <minigui/minigui.h>
#include <minigui/gdi.h>
#include <minigui/window.h>
#include <minigui/control.h>
#include <mdolphin/mdolphin.h>

#define IDC_WEBSITE        107


extern HWND g_website_hwnd;
void mdtv_CreateWebsiteWindow (HWND hParent);



#endif
