#ifndef MDTV_TOOLBAR_H
#define MDTV_TOOLBAR_H

#define TOOLBAR_ITEM_WIDTH      (238)
#define TOOLBAR_ITEM_HEIGHT     (83)
#define TOOLBAR_ARROW_WIDTH     (23)
#define TOOLBAR_ARROW_HEIGHT    (73-7)

HWND InitToolbar(HWND hWnd);
#define ENABLE_FAV 0
#endif
