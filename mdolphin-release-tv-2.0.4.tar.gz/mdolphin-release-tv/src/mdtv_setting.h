void InitSettingPicture();
void UninitSettingPicture();
HWND InitSettingWnd();
