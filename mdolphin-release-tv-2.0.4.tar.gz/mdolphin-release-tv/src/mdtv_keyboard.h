#ifndef MDTV_KEYBOARD_H
#define MDTV_KEYBOARD_H
#include "config.h"
#if MDTV_ENABLE_SOFTIME
HWND mdtv_init_keyboard(HWND hWnd);
#endif

#endif
