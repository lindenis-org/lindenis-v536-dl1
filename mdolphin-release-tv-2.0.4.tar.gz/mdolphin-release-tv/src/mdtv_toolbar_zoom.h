#ifndef MDTV_TOOLBAR_ZOOM_H
#define MDTV_TOOLBAR_ZOOM_H

#define TOOLBAR_WITH_ZOOM    0

#if TOOLBAR_WITH_ZOOM
HWND InitToolbarZoomWnd();
#endif

#endif
