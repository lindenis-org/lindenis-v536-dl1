#ifndef MDTV_FINANCE_H
#define MDTV_FINANCE_H

HWND InitFinanceWnd(void);
#endif/* MDTV_WEATHER_H */
